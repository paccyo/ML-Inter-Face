
from keras.preprocessing.image import *



def preprocess_info():
    ImageDataGenerator_test = ImageDataGenerator()
    flow_from_directory_test = ImageDataGenerator_test.flow_from_directory(r'C:\Users\Yuuki\Documents\GUI_MLearning\GUI_MLearning-main\GUI_MLearning\projects\new_project20240615135240/Data/dataset\test', target_size=(256, 256), color_mode='rgb')
    return flow_from_directory_test