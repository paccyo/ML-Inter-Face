from keras.models import Model
from keras.layers import *


def model_build():
    Input0000 = Input(shape=(256, 256, 3), batch_size=None, dtype=None, sparse=False, batch_shape=None, name=None, tensor=None, detail_view='F')
    Dense0001 = Dense(units='2', use_bias=True, kernel_initializer='glorot_uniform', bias_initializer='zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None, detail_view='F')(Input0000)
    Activation0002 = Activation(activation='softmax', detail_view='F')(Dense0001)
    model = Model(inputs=Input0000, outputs=Activation0002)
    return model